package endtermprojectArucorn;

public enum Faculty {
	BS,
	FIT,
	ISE,
	MKM,
	FOGI,
	BASE
}

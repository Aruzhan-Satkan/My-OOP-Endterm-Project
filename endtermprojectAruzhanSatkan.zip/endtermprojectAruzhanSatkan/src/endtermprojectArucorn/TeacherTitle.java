package endtermprojectArucorn;

public enum TeacherTitle {
	TUTOR,
	LECTOR,
	SENIOR__LECTOR,
	PROFESSOR
}
